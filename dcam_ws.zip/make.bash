source ~/slam_and_nav_ws/install/setup.bash
export MAKEFLAGS="-j2"
colcon build
